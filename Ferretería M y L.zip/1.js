const productos = [
  { id: 1, nombre: "Martillo", precio: 25.5, imagen: "/martillo.jpg" },
  { id: 2, nombre: "Destornillador", precio: 15.0, imagen: "/Destornillador.png" },
  { id: 3, nombre: "Alicate", precio: 20.0, imagen: "/133753.jpg" },
  { id: 4, nombre: "Taladro", precio: 199.9, imagen: "/taladro-atornillador-truper-11020-20-v2719.jpg" },
  { id: 5, nombre: "Caja de herramientas", precio: 89.0, imagen: "/caja-para-herramientas-de-plastica-23-11506-truper.jpg" },
  { id: 6, nombre: "Llave inglesa", precio: 22.0, imagen: "/llave-inglesa-de-tubo-stilson-12-kamasa-km6203.jpg" },
  { id: 7, nombre: "Nivel", precio: 17.0, imagen: "/nivel-de-mano-24-truper.jpg" },
  { id: 8, nombre: "Metro", precio: 9.9, imagen: "/image-30a95826dd0a434b8f2d3fb50d8192d3.jpg" },
  { id: 9, nombre: "Cinta aislante", precio: 3.5, imagen: "/138391.jpg" },
  { id: 10, nombre: "Clavos (100u)", precio: 7.0, imagen: "/31530.jpg" }
];

const listaProductos = document.getElementById("lista-productos");
const carritoLista = document.getElementById("carrito-lista");
const totalDisplay = document.getElementById("total");
const finalizarBtn = document.getElementById("finalizar");

let carrito = [];

productos.forEach(producto => {
  const card = document.createElement("div");
  card.classList.add("producto-card");
  card.innerHTML = `
    <img src="${producto.imagen}" alt="${producto.nombre}">
    <h4>${producto.nombre}</h4>
    <p>S/. ${producto.precio.toFixed(2)}</p>
    <input type="number" min="1" value="1" id="cant-${producto.id}" />
    <button onclick="agregarAlCarrito(${producto.id})">Agregar</button>
  `;
  listaProductos.appendChild(card);
});

function agregarAlCarrito(id) {
  const producto = productos.find(p => p.id === id);
  const cantidad = parseInt(document.getElementById(`cant-${id}`).value);
  if (cantidad <= 0 || isNaN(cantidad)) {
    alert("Ingrese una cantidad válida.");
    return;
  }
  const existente = carrito.find(item => item.id === id);

  if (existente) {
    existente.cantidad += cantidad;
  } else {
    carrito.push({ ...producto, cantidad });
  }
  actualizarCarrito();
}

function actualizarCarrito() {
  carritoLista.innerHTML = "";
  let total = 0;

  carrito.forEach(item => {
    const li = document.createElement("li");
    const subtotal = item.precio * item.cantidad;
    total += subtotal;
    li.textContent = `${item.nombre} x${item.cantidad} - S/. ${subtotal.toFixed(2)}`;
    carritoLista.appendChild(li);
  });

  totalDisplay.textContent = total.toFixed(2);
}

finalizarBtn.addEventListener("click", () => {
  const nombre = document.getElementById("nombre").value.trim();
  const ciudad = document.getElementById("ciudad").value.trim();
  const fecha = document.getElementById("fecha").value;

  if (!nombre || !ciudad || !fecha || carrito.length === 0) {
    alert("Por favor, complete todos los datos y agregue productos al carrito.");
    return;
  }

  const docElement = document.createElement("div");
  docElement.style.padding = "20px";
  docElement.style.fontFamily = "Arial, sans-serif";
  docElement.innerHTML = `
    <h1>FERRETERÍA M y L</h1>
    <p><strong>Cliente:</strong> ${nombre}</p>
    <p><strong>Ciudad:</strong> ${ciudad}</p>
    <p><strong>Fecha:</strong> ${fecha}</p>
    <hr />
    <h2>Detalle de Compra:</h2>
    <ul>
      ${carrito.map(item => `<li>${item.nombre} x${item.cantidad} - S/. ${(item.precio * item.cantidad).toFixed(2)}</li>`).join("")}
    </ul>
    <p><strong>Total:</strong> S/. ${carrito.reduce((acc, item) => acc + item.precio * item.cantidad, 0).toFixed(2)}</p>
  `;

  try {
    html2pdf().from(docElement).save(`Compra_${nombre.replace(/\s+/g, "_")}.pdf`);
  } catch (error) {
    alert("Error al generar PDF. Intenta recargar la página.");
    console.error(error);
  }
});

// Libro de reclamaciones
const formReclamo = document.getElementById("form-reclamo");
formReclamo.addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Gracias por enviar su reclamo. Lo atenderemos pronto.");
  formReclamo.reset();
});
